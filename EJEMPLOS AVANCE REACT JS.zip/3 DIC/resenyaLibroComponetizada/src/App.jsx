import './App.css';
import InfoLibroPage from './pages/InfoLibroPage';

function App() {
  return (
    <>
      <InfoLibroPage />
    </>
  );
}

export default App;
