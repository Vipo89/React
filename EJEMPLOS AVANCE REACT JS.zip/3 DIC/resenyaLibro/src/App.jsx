import './App.css';
import InfoLibroPage from './components/InfoLibroPage';

function App() {
  return (
    <>
      <InfoLibroPage />
    </>
  );
}

export default App;
