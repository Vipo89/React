import React from 'react'

const VehiculoComponent = () => {
  return (
    <div>Vehiculo Component</div>
  )
}

export default VehiculoComponent