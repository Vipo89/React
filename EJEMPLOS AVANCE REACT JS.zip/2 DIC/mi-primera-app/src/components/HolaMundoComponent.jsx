import React from 'react'

const HolaMundoComponent = () => {
  return (
    <div>Hola Mundo</div>
  )
}

export default HolaMundoComponent