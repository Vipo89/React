const wallet = {
  id: 'aosidhsa-32d2d3-2d3dwqed-23e23eer3',
  bitcoin: 24.15,
  ethereum: 6,
};

export default wallet;
