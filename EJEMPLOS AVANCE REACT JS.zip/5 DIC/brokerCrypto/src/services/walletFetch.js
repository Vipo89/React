import wallet from '../mocks/mockup';

const getWallet = () => {
  const dataWallet = { ...wallet };
  return dataWallet;
};

export default getWallet;
