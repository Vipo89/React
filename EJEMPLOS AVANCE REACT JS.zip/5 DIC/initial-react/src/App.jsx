import AutoContadorComponent from '../components/AutoContadorComponent';
import './App.css';

function App() {
  return (
    <>
      <AutoContadorComponent />
    </>
  );
}

export default App;
