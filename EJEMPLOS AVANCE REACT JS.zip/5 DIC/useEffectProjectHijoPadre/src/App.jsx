import './App.css';
import ListaInvitadosPage from './pages/ListaInvitadosPage';

function App() {
  return (
    <>
      <ListaInvitadosPage />
    </>
  );
}

export default App;
