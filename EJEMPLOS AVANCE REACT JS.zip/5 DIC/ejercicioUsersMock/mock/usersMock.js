export let usersMock = [
  {
    id: '616ce9e9-d177-4434-b115-88cbdd39af39',
    name: 'Alejandro Garcia',
    username: 'alejandrogarcia',
    email: 'alejandrogarcia@kmail.com',
  },
  {
    id: '90424e23-c66f-4379-b67a-e8b22131a7ef',
    name: 'Javier Lopez',
    username: 'javierlopez',
    email: 'javierlopez@kmail.com',
  },
  {
    id: '5c00d8b1-c41f-4610-93be-a635bbb0bb8e',
    name: 'Pepa Ruiz',
    username: 'peparuiz',
    email: 'peparuiz@kmail.com',
  },
];
