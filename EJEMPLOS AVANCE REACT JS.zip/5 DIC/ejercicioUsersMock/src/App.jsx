
import './App.css'
import UsersListComponent from '../components/UsersListComponent'

function App() {

  return (
    <>
      <UsersListComponent />
    </>
  )
}

export default App
