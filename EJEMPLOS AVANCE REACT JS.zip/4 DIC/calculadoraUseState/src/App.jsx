import './App.css';
import CalculadoraComponent from './components/CalculadoraComponent';

function App() {
  return (
    <>
      <CalculadoraComponent />
    </>
  );
}

export default App;
