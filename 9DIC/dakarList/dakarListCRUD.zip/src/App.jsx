import './App.css';
import ListaPilotosPage from './pages/ListaPilotosPage';

function App() {
  return (
    <>
      <ListaPilotosPage />
    </>
  );
}

export default App;
